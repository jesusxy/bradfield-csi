## Dynamo Paper

### i. Whats eventual consistency? What benefits are gained by tolerating it? How and when does Dynamo handle conflicts that can arise as a result?

```
Eventual consistency means that all updates will reach all replicas eventually. It allows for updates to be propagated
to all replicas asynchronously. What is gained is having a highly available system during downtimes. Dynamo
allows read and write operations to continue even during network or node failures using hinted handoff.

Tolerating eventual consistency can potentially result in a system having several versions of the same data.
If objects have distinct versions / sub-histories the system will need to reconcile them later in the future.

To handle this, Dynamo uses vector clocks. Vector clock capture the causality between the different versions
of the same obj. We can determine whether two versions of an object have causal ordering by examining
these vector clocks. This determines which objects are ancestors of the others, which objects are stale and can
be forgotten, and which need to be reconciled.

Another issue that can arise is the size of the vector clocks growing if too many servers
coordinate writes an object. Its not likely to happen but a way to prevent this the size of the vector
clock can be limited. Dynamo employs a truncation scheme to remove the oldest (node, counter) pairs from the clock.
```

### ii. What conditions on the Dynamo cluster configuration are needed to guarantee that if a client writes a value for a given key, a subsequent read of the same key by the same client will include the value that was just written? Please include justification for your answer.

```
You can assume that ”hinted handoff” and ”sloppy quorum” are disabled, and that each key’s preference
list has exactly N items.

I think this section of the paper summarizes the write-read guarantee.

"In particular, since each write usually follows a read operation, the
coordinator for a write is chosen to be the node that replied fastest
to the previous read operation which is stored in the context information
of the request. This optimization enables us to pick the node that has the
data that was read by the preceding read operation thereby
increasing the chances of getting “read-your-writes” consistency."

Also assuming that all nodes in the preference list are healthy, there will always be a minimum number of
nodes that will participate in a succesful read / write operation. At least R-1 || W-1 nodes will
respond to the operations and deem them succesful.
```

### iii. When using "consistent hashing", how does the coordinator determine the node(s) responsible for a particular key? What state or data structures are involved, and how does the state change when a node is added or removed from the cluster?

```
When a node gets added to the system it is assigned a number of tokens that are scattered throughout the ring.
Tokens are the position / location in the ring. These tokens correspond to the key ranges that the storage
node will be responsible for. Each storage node is aware of the token ranges handled by
its peers in the ring, which means the coordinator knows where to forward the read/write operations to the
correct set of nodes that handle the key.

The only state change that happens when a node is added / removed to the cluster is a transfer of keys.
A confirmation happens between source and destination nodes to ensure no duplicate transfers of key ranges happen.

Adding / removing nodes only affects the immediate neighbors, other nodes will remain unaffected.

A Gossip based protocol propagates ring membership changes and maintains a consistent view of ring membership.
```

### iv. What are the tradeoffs between (a) consistent hashing and (b) assigning a given key to the nodes using the result of hash(key) % CLUSTER_SIZE?
