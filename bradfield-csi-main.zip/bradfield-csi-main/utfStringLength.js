/***
 * After watching the computerphile video on UTF-8, it became clear on how to
 * solve this problem.
 *
 * In UTF-8 encoding, the first byte of each character indicates how many bytes the character occupies in the string.
 * The most significant bits of the first byte determine the length of the character.
 *  
 *  Single-byte character: 0xxxxxxx
    Two-byte character:    110xxxxx 10xxxxxx
    Three-byte character:  1110xxxx 10xxxxxx 10xxxxxx
    Four-byte character:   11110xxx 10xxxxxx 10xxxxxx 10xxxxxx

 * Using this we can begin to count the number of characters in the string from the byte array.
 * To extract the length of the character from the first byte we can use either decimal values
 * of the binary or bitmasks.
 *
 */

const utf8StringLen = (byteArray) => {
  let count = 0;
  let i = 0;

  while (i < byteArray.length) {
    if ((byteArray[i] & 0x80) === 0) {
      // single-byte character
      count++;
      i++;
    } else if ((byteArray[i] & 0xe0) === 0xc0) {
      // two-byte character
      count++;
      i += 2;
    } else if ((byteArray[i] & 0xf0) === 0xe0) {
      // three-byte character
      count++;
      i += 3;
    } else if ((byteArray[i] & 0xf8) === 0xf0) {
      count++;
      i += 4;
    }
  }

  return count;
};
