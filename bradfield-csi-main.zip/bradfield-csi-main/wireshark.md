## Network packet capture

## i. Find the DNS query for bradfieldcs.com How many answers were provided, and what were the ”time to live” values of each answer in seconds?

A total of 16 DNS answers were provided. These answers included both requests from the source (my laptop) and
responses from the destination in this case `192.168.1.1`.

~~The time to live (TTL) values for each of these answers was `64`. I believe the TTL values are set in seconds, so
64 seconds.~~

After feedback from Elliott it seems I was looking at the wrong section of the packet. The above answer was from the Internet Protocol section. 
I found the packet that has the TTL in the DNS section of the packet. The TTL here is `300 seconds` or 5 minutes.

<img width="1468" alt="new_ttl" src="https://user-images.githubusercontent.com/53798994/226062747-f6ef50d2-dd88-4a52-8423-3e3f83e9902e.png">

## ii. Find the SYN/ACK segment sent from port 443 of the Bradfield server. What receive window size did the server advertise?

In the `SYN/ACK` segment the receive window size for the bradfield server is `64704` bytes.

<img width="1454" alt="window_size" src="https://user-images.githubusercontent.com/53798994/224567327-42e0807f-9f10-47a3-b5d8-eca17aa07ded.png">

## iii. During the TLS handshake the cipher suite that was selected by the Bradfield server is: `TLS_AES_128_GCM_SHA256`

Truthfully, I am not 100% sure that this is from the Bradfield server. When the DNS query was made I saw that the Bradfield IP
was `170.20.10.10`. The source and destination values changed during the TLS handshake to `ipv6 addresses`, but I am going to assume this is correct
because this TLS handshake happened right after the DNS query to `bradfieldcs.com`.

<img width="1461" alt="tls_handshake" src="https://user-images.githubusercontent.com/53798994/224567354-d449bbf3-ff70-48c9-aeb4-718f8ca6e40d.png">
