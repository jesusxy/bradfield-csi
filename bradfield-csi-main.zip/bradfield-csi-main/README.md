# bradfield-csi
Take home exercises for Bradfield CSI 

First off, I want to start by saying this was incredibly fun to do. I definetely was challenged on some of these tasks. This was my first time ever
reading a technical paper and I learned a whole lot from the Dynamo one. 

Ive named each of the files with its corresponding task name. Below are some notes for two of the tasks.

## UTF-8 string length

The `utfStringLength.js` was ~left blank~ **completed!!** This was the most challenging of all the tasks. 

~I understand what was being asked, but truthfully, I could not think of how to convert
a UTF-8 byte array into a string. Returning the length of the string is easy, in Javascript its a simple `string.length()`.~

After watching the computerphile video and learning of the UTF8 hack where the first byte of each character indicates how many 
bytes the character occupies in the string, it made complete sense on how to do the conversion.

~But using these in order to make the conversions is where I was stuck. I did find ways to do it using libraries / packages but that was not allowed
for the task.~ 


## Time zone task

To run the server you simply run `npm start`. 
The following queries are supported by the server.

To get the current UTC time you run:
```
curl -x GET "localhost:3000/time"
```

If you would like to pass a specific timezone you run:
```
curl -X GET "localhost:3000/time?tz=America/Los_Angeles" 
```

You should see the result in your terminal.

curl -X GET "localhost:3000/time?tz=America/New_York"

Terminal logs: 
```
* Connected to localhost (127.0.0.1) port 3000 (#0)
> POST /time HTTP/1.1
> Host: localhost:3000
> User-Agent: curl/7.79.1
> Accept: */*
> Content-Length: 19
> Content-Type: application/x-www-form-urlencoded
> 
* Mark bundle as not supporting multiuse
< HTTP/1.1 200 OK
< server: my-custom-server
< content-type: application/json; charset=utf-8
< content-length: 26
< date: Sun, 12 Mar 2023 20:28:09 GMT
< 
* Connection #0 to host localhost left intact
{"currentTime":"04:28:09"}  
```

The first half will be the request headers. 
Second half is the response headers with the `currentTime` object.

If you make a query with a unsupported path like `localhost:3000/hello` an error should be returned
```
{ error: 'This path is not supported on our server' }
```
